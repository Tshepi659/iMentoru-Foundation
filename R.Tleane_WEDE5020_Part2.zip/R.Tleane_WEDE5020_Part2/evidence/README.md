# Responsive screenshot evidence

Before final submission, use the browser developer-tools device toolbar to capture the home page at these sizes:

- `desktop-1440x900.png` — 1440 × 900
- `tablet-768x1024.png` — 768 × 1024
- `mobile-390x844.png` — 390 × 844

For each view, confirm that there is no horizontal scrolling, text is readable, images scale correctly, navigation works, and multi-column content changes appropriately on smaller screens.
