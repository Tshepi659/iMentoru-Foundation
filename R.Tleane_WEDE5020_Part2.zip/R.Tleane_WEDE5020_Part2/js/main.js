
document.addEventListener('DOMContentLoaded',()=>{
 const menu=document.querySelector('.menu-btn'), links=document.querySelector('.navlinks');
 if(menu && links) menu.addEventListener('click',()=>{
   const isOpen=links.classList.toggle('open');
   menu.setAttribute('aria-expanded',String(isOpen));
   menu.setAttribute('aria-label',isOpen?'Close navigation':'Open navigation');
 });
 if(links) links.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{
   links.classList.remove('open');
   if(menu){menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Open navigation');}
 }));
 document.querySelectorAll('form[data-demo]').forEach(form=>{
   form.addEventListener('submit',e=>{
     e.preventDefault();
     const flash=form.parentElement.querySelector('.flash');
     if(flash){flash.style.display='block';flash.textContent='Thank you. Your submission has been recorded for this website demonstration.';form.reset();}
   });
 });
});
